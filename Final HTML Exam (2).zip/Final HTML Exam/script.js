document.addEventListener("DOMContentLoaded", function() {
    // Find the profile element
    var profile = document.querySelector(".profile");

    // Attach an event listener to the profile's submit event
    profile.addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent the default profile submission

        // Get the value from the "Leave a Message" input field
        var messageInput = document.getElementById("input1");
        var message = messageInput.value;

        // Display an alert with the message
        alert("You've submitted the following message: " + message);

        // Clear the input field
        messageInput.value = "";
    });
});
